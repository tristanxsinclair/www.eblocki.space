# Apply Instructions

This folder is a fallback export of the verified Proof First Submission Simplification v1 implementation.

Copy only these files into the real repo at the same repo-relative paths:

- `src/lib/eblocki/first-proof.ts`
- `src/pages/Proof.tsx`
- `src/lib/eblocki/__tests__/first-proof.test.ts`

Do not copy `node_modules`, `dist`, package files, lockfiles, Supabase files, screenshots, or unrelated files.

After copying, run:

```bash
pnpm test
pnpm run build
pnpm exec tsc --noEmit
pnpm exec eslint src/lib/eblocki/first-proof.ts src/pages/Proof.tsx src/lib/eblocki/__tests__/first-proof.test.ts
```

If available, also run:

```bash
pnpm run smoke:routes
```

Then complete authenticated browser QA:

- Sign in.
- Open `/proof?first=1`.
- Confirm the first viewport is plain student-facing copy.
- Confirm mode/proof-type controls are behind `Advanced details`.
- Submit a real first proof and check the simplified verdict.
- Confirm normal `/proof` still shows the full standard preview and normal advanced flow.
